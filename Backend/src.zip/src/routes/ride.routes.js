import express from "express";
import { bookRide } from "../controllers/ride.controller.js";

const router = express.Router();

router.post("/book-ride", bookRide); // This will handle POST /api/bookings/book-ride

export default router;