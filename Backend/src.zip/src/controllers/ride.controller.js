// In your Backend/src/controllers/ride.controller.js
export const bookRide = async (req, res) => {
  try {
    const { userId, fromLocation, toLocation, vehicleType, rideType } = req.body;
    
    // Validate input
    if (!userId || !fromLocation || !toLocation) {
      return res.status(400).json({ 
        success: false, 
        message: "Missing required fields" 
      });
    }

    // Insert into database
    const result = await executeQuery(
      `INSERT INTO rides 
       (user_id, from_location, to_location, vehicle_type, ride_type, status) 
       VALUES (:userId, :fromLocation, :toLocation, :vehicleType, :rideType, 'pending') 
       RETURNING id`,
      { userId, fromLocation, toLocation, vehicleType, rideType }
    );

    const rideId = result.rows[0].id;
    
    // Emit socket event
    req.io.emit("rideRequested", { rideId });
    
    res.status(201).json({ 
      success: true, 
      rideId,
      message: "Ride booked successfully" 
    });
    
  } catch (error) {
    console.error("Error booking ride:", error);
    res.status(500).json({ 
      success: false, 
      message: "Failed to book ride" 
    });
  }
};